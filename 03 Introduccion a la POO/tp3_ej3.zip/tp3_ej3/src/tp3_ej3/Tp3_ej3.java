package tp3_ej3;

/**
 *
 * @author Agustin Echeverria Araya
 */

public class Tp3_ej3 {
    public static void main(String[] args) {
        Libro libro = new Libro("Redes de Computadoras", "Andrew S. Tanenbaum", 1981);
        libro.mostrarInfo();
        libro.setAñoPublicacion(-100);  // Inválido
        libro.setAñoPublicacion(2013);  // Válido
        libro.mostrarInfo();
    }
}
