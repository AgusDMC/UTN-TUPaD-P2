package tp3_ej2;

/**
 *
 * @author Agustin Echeverria Araya
 */

public class Tp3_ej2 {
    public static void main(String[] args) {
        Mascota mascota = new Mascota("Indiana", "Perro", 3);
        mascota.mostrarInfo();
        mascota.cumplirAnios();
        mascota.mostrarInfo();
        mascota.cumplirAnios();
        mascota.mostrarInfo();
    }
}
