package tp3_ej5;

/**
 *
 * @author Agustin Echeverria Araya
 */
public class Tp3_ej5 {
    public static void main(String[] args) {
        NaveEspacial nave = new NaveEspacial("Enterprise", 50);
        nave.avanzar(60);  // Intento sin recargar (fallará)
        nave.recargarCombustible(20);  // Recargar
        nave.avanzar(60);  // Ahora sí
        nave.mostrarEstado();
    }
}
