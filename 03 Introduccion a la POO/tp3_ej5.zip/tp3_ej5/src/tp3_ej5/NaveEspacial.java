package tp3_ej5;

/**
 *
 * @author Agustin Echeverria Araya
 */

public class NaveEspacial {
    private String nombre;
    private int combustible;
    private final int MAX_COMBUSTIBLE = 100;  // Límite asumido para recarga

    public NaveEspacial(String nombre, int combustible) {
        this.nombre = nombre;
        this.combustible = combustible;
    }

    public void despegar() {
        if (combustible >= 10) {  // Asumiendo consumo de 10 para despegar
            combustible -= 10;
            System.out.println(nombre + " ha despegado. Combustible restante: " + combustible);
        } else {
            System.out.println("Error: Combustible insuficiente para despegar.");
        }
    }

    public void avanzar(int distancia) {
        int consumo = distancia;  // Asumiendo 1 unidad por distancia
        if (combustible >= consumo) {
            combustible -= consumo;
            System.out.println(nombre + " ha avanzado " + distancia + " unidades. Combustible restante: " + combustible);
        } else {
            System.out.println("Error: Combustible insuficiente para avanzar " + distancia + " unidades.");
        }
    }

    public void recargarCombustible(int cantidad) {
        if (combustible + cantidad <= MAX_COMBUSTIBLE) {
            combustible += cantidad;
            System.out.println("Recargado " + cantidad + " unidades. Combustible actual: " + combustible);
        } else {
            System.out.println("Error: No se puede superar el límite de " + MAX_COMBUSTIBLE + " unidades.");
        }
    }

    public void mostrarEstado() {
        System.out.println("Nave: " + nombre);
        System.out.println("Combustible: " + combustible + " / " + MAX_COMBUSTIBLE);
    }
}
