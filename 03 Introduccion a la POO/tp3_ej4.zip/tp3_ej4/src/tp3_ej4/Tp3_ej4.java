package tp3_ej4;

/**
 *
 * @author Agustin Echeverria Araya
 */

public class Tp3_ej4 {
    public static void main(String[] args) {
        Gallina gallina1 = new Gallina(1, 2, 50);
        Gallina gallina2 = new Gallina(2, 3, 70);

        gallina1.envejecer();
        gallina1.ponerHuevo();
        gallina1.ponerHuevo();
        gallina1.mostrarEstado();

        gallina2.envejecer();
        gallina2.ponerHuevo();
        gallina2.mostrarEstado();
    }
}
