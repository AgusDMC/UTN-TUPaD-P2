package tp3_ej1;

/**
 *
 * @author Agustin Echeverria Araya
 */
public class Tp3_ej1 {
    public static void main(String[] args) {
        Estudiante estudiante = new Estudiante("Juan", "Pérez", "Programación II", 7.5);
        estudiante.mostrarInfo();
        estudiante.subirCalificacion(1.5);
        estudiante.mostrarInfo();
        estudiante.bajarCalificacion(0.5);
        estudiante.mostrarInfo();
    }
}
