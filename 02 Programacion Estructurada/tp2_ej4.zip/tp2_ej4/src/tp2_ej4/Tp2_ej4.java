package tp2_ej4;
import java.util.Scanner;

/**
 *
 * @author Agustin Echeverria Araya
 */

public class Tp2_ej4 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Ingrese el precio del producto: ");
        double precio = input.nextDouble();
        System.out.print("Ingrese la categoría (A, B o C): ");
        char cat = input.next().trim().toUpperCase().charAt(0);

        // Determinamos porcentaje según categoría
        double pct;
        if (cat == 'A') pct = 0.10;
        else if (cat == 'B') pct = 0.15;
        else if (cat == 'C') pct = 0.20;
        else pct = 0.0;

        // Calculamos precio final
        double precioFinal = precio * (1 - pct);

        System.out.println("Descuento aplicado: " + (int)(pct * 100) + "%");
        System.out.println("Precio final: " + precioFinal);

        input.close();
    }
}
