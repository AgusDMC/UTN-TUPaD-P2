package tp2_ej13;
import java.util.Scanner;

/**
 *
 * @author Agustin Echeverria Araya
 */

public class Tp2_ej13 {
    public static void imprimirArrayRecursivo(double[] array, int index) {
        if (index >= array.length) {
            return;
        }
        System.out.println("Precio: $" + array[index]);
        imprimirArrayRecursivo(array, index + 1);
    }
    
    public static void main(String[] args) {
        double[] precios = {199.99, 299.5, 149.75, 399.0, 89.99};
        
        System.out.println("Precios originales:");
        imprimirArrayRecursivo(precios, 0);
        
        // Modificar el precio del tercer producto (índice 2)
        precios[2] = 129.99;
        
        System.out.println("Precios modificados:");
        imprimirArrayRecursivo(precios, 0);
    }
}
