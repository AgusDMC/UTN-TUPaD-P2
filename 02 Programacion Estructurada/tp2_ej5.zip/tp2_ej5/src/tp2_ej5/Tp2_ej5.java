package tp2_ej5;
import java.util.Scanner;

/**
 *
 * @author Agustin Echeverria Araya
 */

public class Tp2_ej5 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int suma = 0;

        // Pedimos números hasta que ingrese 0
        System.out.print("Ingrese números (0 para terminar):");
        int n = input.nextInt();
        while (n != 0) {
          if (n % 2 == 0) suma += n; // sólo sumamos pares
          System.out.print("Ingrese números (0 para terminar):");
          n = input.nextInt();
        }

        System.out.println("La suma de pares es: " + suma);
        input.close();
    }
}
