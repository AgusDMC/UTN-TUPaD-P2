package tp2_ej12;
import java.util.Scanner;

/**
 *
 * @author Agustin Echeverria Araya
 */

public class Tp2_ej12 {
   public static void main(String[] args) {
        double[] precios = {199.99, 299.5, 149.75, 399.0, 89.99};
        
        System.out.println("Precios originales:");
        for (double precio : precios) {
            System.out.println("Precio: $" + precio);
        }
        
        // Modificar el precio del tercer producto (índice 2)
        precios[2] = 129.99;
        
        System.out.println("Precios modificados:");
        for (double precio : precios) {
            System.out.println("Precio: $" + precio);
        }
    }
}
