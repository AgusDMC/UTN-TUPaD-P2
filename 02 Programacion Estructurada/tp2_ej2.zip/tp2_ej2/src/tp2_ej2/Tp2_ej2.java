package tp2_ej2;
import java.util.Scanner;

/**
 *
 * @author Agustin Echeverria Araya
 */

public class Tp2_ej2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Ingrese el primer número: ");
        int a = input.nextInt();
        System.out.print("Ingrese el segundo número: ");
        int b = input.nextInt();
        System.out.print("Ingrese el tercer número: ");
        int c = input.nextInt();
        int mayor = Math.max(a, Math.max(b, c));
        System.out.println("El mayor es: " + mayor);
        input.close();
    }
}
