package tp2_ej7;
import java.util.Scanner;

/**
 *
 * @author Agustin Echeverria Araya
 */

public class Tp2_ej7 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int nota;
        // Pedimos hasta que esté entre 0 y 10
        do {
          System.out.print("Ingrese una nota (0-10): ");
          nota = input.nextInt();
          if (nota < 0 || nota > 10) {
            System.out.println("Error: nota inválida.");
          }
        } while (nota < 0 || nota > 10);

        System.out.println("Nota guardada: " + nota);
        input.close();
    }
}
