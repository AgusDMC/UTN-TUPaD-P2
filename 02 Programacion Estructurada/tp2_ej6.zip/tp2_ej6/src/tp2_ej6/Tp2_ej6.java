package tp2_ej6;
import java.util.Scanner;

/**
 *
 * @author Agustin Echeverria Araya
 */

public class Tp2_ej6 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int pos = 0, neg = 0, cer = 0;

        // Leemos 10 números y contamos
        for (int i = 1; i <= 10; i++) {
          System.out.print("Ingrese el número " + i + ": ");
          int x = input.nextInt();
          if (x > 0) pos++;
          else if (x < 0) neg++;
          else cer++;
        }

        // Mostramos resultados
        System.out.println("Positivos: " + pos);
        System.out.println("Negativos: " + neg);
        System.out.println("Ceros: " + cer);
        input.close();
    }
}
