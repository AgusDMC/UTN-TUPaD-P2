package tp5_ej9;
/**
 *
 * @author AgusDMC
 */
public class Tp5_ej9 {
    public static void main(String[] args) {
        Paciente paciente = new Paciente("Santiago Chavez", "SEMPRE");
        Profesional profesional = new Profesional("Dr. Silva", "Cardiologia");
        CitaMedica cita = new CitaMedica("2025-11-15", "10:00");
        cita.setPaciente(paciente);
        cita.setProfesional(profesional);
        System.out.println("Cita: " + cita.getFecha() + " - Paciente: " + cita.getPaciente().getNombre());
    }
}
