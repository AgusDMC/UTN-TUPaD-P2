package tp5_ej4;
/**
 *
 * @author AgusDMC
 */
public class Tp5_ej4 {
    public static void main(String[] args) {
        Cliente cliente = new Cliente("Julian Echeverria", "44120474");
        Banco banco = new Banco("Banco de La Pampa", "20-44120474-8");
        TarjetaDeCredito tarjeta = new TarjetaDeCredito("1234-5678-9123-4567", "12/30", banco);
        cliente.setTarjeta(tarjeta);
        System.out.println("Tarjeta: " + tarjeta.getNumero() + " - Cliente: " + tarjeta.getCliente().getNombre());
    }
}
