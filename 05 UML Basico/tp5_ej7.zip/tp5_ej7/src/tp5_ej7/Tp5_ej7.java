package tp5_ej7;
/**
 *
 * @author AgusDMC
 */
public class Tp5_ej7 {
    public static void main(String[] args) {
        Motor motor = new Motor("Diesel", "M12345");
        Conductor conductor = new Conductor("Pedro Luro", "LIC-001");
        Vehiculo vehiculo = new Vehiculo("ABC123", "Toyota Hilux", motor);
        vehiculo.setConductor(conductor);
        System.out.println("Vehiculo: " + vehiculo.getModelo() + " - Conductor: " + vehiculo.getConductor().getNombre());
    }
}
