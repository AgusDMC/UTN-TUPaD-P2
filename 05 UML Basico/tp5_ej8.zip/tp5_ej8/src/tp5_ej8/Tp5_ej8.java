package tp5_ej8;
/**
 *
 * @author AgusDMC
 */
public class Tp5_ej8 {
    public static void main(String[] args) {
        Usuario usuario = new Usuario("Elena Torres", "elena@example.com");
        Documento documento = new Documento("Contrato", "xxxxxxxxx", "HASH123", "2025-09-01", usuario);
        System.out.println("Documento: " + documento.getTitulo() + " - Firma por: " + documento.getFirmaDigital().getUsuario().getNombre());
    }
}
