package tp5_ej1;
/**
 *
 * @author AgusDMC
 */
public class Tp5_ej1 {
    public static void main(String[] args) {
        Titular titular = new Titular("Agustin Echeverria", "40954174");
        Pasaporte pasaporte = new Pasaporte("AAAA1234", "2025-01-01", "imagen.png", "PNG");
        titular.setPasaporte(pasaporte);
        System.out.println("Pasaporte número: " + pasaporte.getNumero());
        System.out.println("Titular: " + pasaporte.getTitular().getNombre());
        System.out.println("Foto: " + pasaporte.getFoto().getImagen());
    }
}
