package tp5_ej13;
/**
 *
 * @author AgusDMC
 */
public class Tp5_ej13 {
    public static void main(String[] args) {
        Usuario usuario = new Usuario("Oscar Alpa", "alpa@gmail.com");
        GeneradorQR generador = new GeneradorQR();
        generador.generar("000123", usuario);
    }
}
