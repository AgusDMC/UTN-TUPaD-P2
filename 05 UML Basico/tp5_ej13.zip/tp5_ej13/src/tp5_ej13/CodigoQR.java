package tp5_ej13;
/**
 *
 * @author AgusDMC
 */
public class CodigoQR {
    private String valor;
    private Usuario usuario;

    public CodigoQR(String valor, Usuario usuario) {
        this.valor = valor;
        this.usuario = usuario;
    }
    
    public CodigoQR() { }

    public String getValor() { return valor; }

    public Usuario getUsuario() { return usuario; }
    
    public void setValor(String valor) {  this.valor = valor; }

    public void setUsuario(Usuario usuario) { this.usuario = usuario; } 
    
}
