package tp5_ej13;
/**
 *
 * @author AgusDMC
 */
public class GeneradorQR {
    public void generar(String valor, Usuario usuario) { // Dependencia de creación: crea CodigoQR internamente, sin atributo
        CodigoQR qr = new CodigoQR(valor,usuario);
        qr.setUsuario(usuario);
        System.out.println("QR generado: " + qr.getValor() + " para " + qr.getUsuario().getNombre());
    }
}
