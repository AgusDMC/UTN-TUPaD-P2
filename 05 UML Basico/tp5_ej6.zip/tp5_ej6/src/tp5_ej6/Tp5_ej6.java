package tp5_ej6;
/**
 *
 * @author AgusDMC
 */
public class Tp5_ej6 {
    public static void main(String[] args) {
        Cliente cliente = new Cliente("Laura Martinez", "555-1234");
        Mesa mesa = new Mesa(5, 4);
        Reserva reserva = new Reserva("2025-10-01", "20:00", mesa);
        reserva.setCliente(cliente);
        System.out.println("Reserva: " + reserva.getFecha() + " - Cliente: " + reserva.getCliente().getNombre());
    }
}
