package tp5_ej6;
/**
 *
 * @author AgusDMC
 */
public class Reserva {
    private String fecha;
    private String hora;
    private Cliente cliente;
    private Mesa mesa;

    public Reserva(String fecha, String hora, Mesa mesa) {
        this.fecha = fecha;
        this.hora = hora;
        this.mesa = mesa;
    }

    public String getFecha() { return fecha; }

    public String getHora() { return hora; }

    public Cliente getCliente() { return cliente; }

    public Mesa getMesa() { return mesa; }
    
    public void setFecha(String fecha) { this.fecha = fecha; }
    
    public void setHora(String hora) { this.hora = hora; }
    
    public void setCliente(Cliente cliente) { this.cliente = cliente; }

    public void setMesa(Mesa mesa) { this.mesa = mesa; }
}
