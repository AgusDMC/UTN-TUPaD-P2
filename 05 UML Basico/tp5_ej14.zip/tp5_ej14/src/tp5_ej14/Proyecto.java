package tp5_ej14;
/**
 *
 * @author AgusDMC
 */
public class Proyecto {
    private String nombre;
    private int duracionMin;

    public Proyecto(String nombre, int duracionMin) {
        this.nombre = nombre;
        this.duracionMin = duracionMin;
    }

    public Proyecto() { }

    public String getNombre() { return nombre; }

    public int getDuracionMin() { return duracionMin; }
    
    public void setNombre(String nombre) { this.nombre = nombre; }

    public void setDuracionMin(int duracionMin) { this.duracionMin = duracionMin; }
}
