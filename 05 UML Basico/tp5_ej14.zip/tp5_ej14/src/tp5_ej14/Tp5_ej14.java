package tp5_ej14;
/**
 *
 * @author AgusDMC
 */
public class Tp5_ej14 {
    public static void main(String[] args) {
        Proyecto proyecto = new Proyecto("Video Promo", 10);
        EditorVideo editor = new EditorVideo();
        editor.exportar("MP4", proyecto);
    }
}
