package tp5_ej14;
/**
 *
 * @author AgusDMC
 */
public class EditorVideo {
    public void exportar(String formato, Proyecto proyecto) { // Dependencia de creación: crea Render internamente, sin atributo
        Render render = new Render(formato, proyecto);
        System.out.println("Exportando render en " + render.getFormato() + " para proyecto " + render.getProyecto().getNombre());
    }
}
