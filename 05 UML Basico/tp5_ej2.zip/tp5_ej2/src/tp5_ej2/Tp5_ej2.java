package tp5_ej2;
/**
 *
 * @author AgusDMC
 */
public class Tp5_ej2 {
    public static void main(String[] args) {
        Usuario usuario = new Usuario("Agustin Echeverria", "40954174");
        Bateria bateria = new Bateria("BAT-001", 5000);
        Celular celular = new Celular("Samsung", "A54", "1111111111", bateria);
        usuario.setCelular(celular);
        System.out.println("Usuario: " + celular.getUsuario().getNombre());
        System.out.println("Batería: " + celular.getBateria().getModelo());
    }
}
