package tp5_ej2;
/**
 *
 * @author AgusDMC
 */
public class Celular {
    private String marca;
    private String modelo;
    private String imei;
    private Bateria bateria;
    private Usuario usuario;

    public Celular(String marca, String modelo, String imei, Bateria bateria) {
        this.marca = marca;
        this.modelo = modelo;
        this.imei = imei;
        this.bateria = bateria;
    }

    public String getMarca() { return marca; }

    public String getModelo() { return modelo; }

    public String getImei() { return imei; }

    public Bateria getBateria() { return bateria; }

    public Usuario getUsuario() { return usuario; }
    
    public void setMarca(String marca) { this.marca = marca; }
    
    public void setModelo(String modelo) { this.modelo = modelo;}
    
    public void setImei(String imei) { this.imei = imei; }
    
    public void setBateria(Bateria bateria) { this.bateria = bateria; }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
        if (usuario != null && usuario.getCelular() != this) {
            usuario.setCelular(this);
        }
    }
}
