package tp5_ej10;
/**
 *
 * @author AgusDMC
 */
public class Tp5_ej10 {
    public static void main(String[] args) {
        Titular titular = new Titular("Luis Echeverria", "18678901");
        CuentaBancaria cuenta = new CuentaBancaria("000111222333", 90000.0, "SEC123", "2025-01-01");
        cuenta.setTitular(titular);
        System.out.println("Cuenta: " + cuenta.getCbu() + " - Titular: " + cuenta.getTitular().getNombre());
    }
}
