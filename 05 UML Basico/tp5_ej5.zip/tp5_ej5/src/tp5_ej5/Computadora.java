package tp5_ej5;
/**
 *
 * @author AgusDMC
 */
public class Computadora {
    private String marca;
    private String numeroSerie;
    private PlacaMadre placaMadre;
    private Propietario propietario;

    public Computadora(String marca, String numeroSerie, String modelo, String chipset) {
        this.marca = marca;
        this.numeroSerie = numeroSerie;
        this.placaMadre = new PlacaMadre(modelo, chipset);
    }

    public String getMarca() { return marca; }

    public String getNumeroSerie() { return numeroSerie; }

    public PlacaMadre getPlacaMadre() { return placaMadre; }

    public Propietario getPropietario() { return propietario; }
    
    public void setMarca(String marca) { this.marca = marca; }
    
    public void setNumeroSerie(String numeroSerie) { this.numeroSerie = numeroSerie; }
    
    public void setPlacaMadre(PlacaMadre placaMadre) { this.placaMadre = placaMadre; }

    public void setPropietario(Propietario propietario) {
        this.propietario = propietario;
        if (propietario != null && propietario.getComputadora() != this) {
            propietario.setComputadora(this);
        }
    }
}
