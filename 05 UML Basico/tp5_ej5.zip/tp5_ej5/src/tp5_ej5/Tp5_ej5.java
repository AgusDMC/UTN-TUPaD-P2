package tp5_ej5;
/**
 *
 * @author AgusDMC
 */
public class Tp5_ej5 {
    public static void main(String[] args) {
        Propietario propietario = new Propietario("Maria Paula", "34567890");
        Computadora computadora = new Computadora("Dell", "SN12345", "MB-001", "Intel I5");
        computadora.setPropietario(propietario);
        System.out.println("Computadora: " + computadora.getMarca() + " - Propietario: " + computadora.getPropietario().getNombre());
    }
}
