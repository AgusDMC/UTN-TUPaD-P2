package tp5_ej12;
/**
 *
 * @author AgusDMC
 */
public class Calculadora {
    public void calcular(Impuesto impuesto) { // Dependencia de uso: usa Impuesto como parámetro, sin atributo
        System.out.println("Calculando impuesto de " + impuesto.getMonto() + " para " + impuesto.getContribuyente().getNombre());
    }
}
