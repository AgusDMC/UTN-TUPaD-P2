package tp5_ej12;
/**
 *
 * @author AgusDMC
 */
public class Tp5_ej12 {
    public static void main(String[] args) {
        Contribuyente contribuyente = new Contribuyente("Empatel", "30-12345678-9");
        Impuesto impuesto = new Impuesto(300.0, contribuyente);
        Calculadora calculadora = new Calculadora();
        calculadora.calcular(impuesto);
    }
}
