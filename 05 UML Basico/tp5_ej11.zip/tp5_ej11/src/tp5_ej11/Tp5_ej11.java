package tp5_ej11;
/**
 *
 * @author AgusDMC
 */
public class Tp5_ej11 {
    public static void main(String[] args) {
        Artista artista = new Artista("The Beatles", "Rock");
        Cancion cancion = new Cancion("Hey Jude", artista);
        Reproductor reproductor = new Reproductor();
        reproductor.reproducir(cancion);
    }
}
