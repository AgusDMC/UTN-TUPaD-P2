package tp5_ej11;
/**
 *
 * @author AgusDMC
 */
public class Reproductor {
    public void reproducir(Cancion cancion) { // Dependencia de uso: usa Cancion como parámetro, sin atributo
        System.out.println("Reproduciendo: " + cancion.getTitulo() + " de " + cancion.getArtista().getNombre());
    }
}
