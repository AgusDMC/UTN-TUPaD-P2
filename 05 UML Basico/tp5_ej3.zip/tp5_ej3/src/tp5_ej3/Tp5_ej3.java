package tp5_ej3;
/**
 *
 * @author AgusDMC
 */
public class Tp5_ej3 {
    public static void main(String[] args) {
        Autor autor = new Autor("George R. R. Martin", "Estadounidense");
        Editorial editorial = new Editorial("Bantam", "mi casa 1234");
        Libro libro = new Libro("A Game of Thrones", "978-0553573404", editorial);
        libro.setAutor(autor);
        System.out.println("Libro: " + libro.getTitulo() + " - Autor: " + libro.getAutor().getNombre());
    }
}
