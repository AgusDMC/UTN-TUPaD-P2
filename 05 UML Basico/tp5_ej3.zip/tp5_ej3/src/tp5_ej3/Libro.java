package tp5_ej3;
/**
 *
 * @author AgusDMC
 */
public class Libro {
    private String titulo;
    private String isbn;
    private Autor autor;
    private Editorial editorial;

    public Libro(String titulo, String isbn, Editorial editorial) {
        this.titulo = titulo;
        this.isbn = isbn;
        this.editorial = editorial;
    }

    public String getTitulo() { return titulo; }

    public String getIsbn() { return isbn; }

    public Autor getAutor() { return autor; }
    
    public Editorial getEditorial() { return editorial; }
    
    public void setTitulo(String titulo) { this.titulo = titulo; }
    
    public void setIsbn(String isbn) { this.isbn = isbn; }
    
    public void setAutor(Autor autor) { this.autor = autor; }

    public void setEditorial(Editorial editorial) { this.editorial = editorial; }
}
