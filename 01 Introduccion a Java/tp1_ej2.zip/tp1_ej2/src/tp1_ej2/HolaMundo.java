package tp1_ej2;

/**
 *
 * @author Agustin Echeverria Araya
 */

public class HolaMundo {
    
    public static void main(String[] args) {
        System.out.println("¡Hola, Java!");
    }
    
}
