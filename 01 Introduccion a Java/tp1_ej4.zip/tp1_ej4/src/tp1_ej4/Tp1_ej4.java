package tp1_ej4;

/**
 *
 * @author Agutin Echeveria Araya
 */

import java.util.Scanner;

public class Tp1_ej4 {

    public static void main(String[] args) {
        //Declaro las variables
        Scanner input = new Scanner(System.in);
        String nombre;
        int edad;
        
        //Pido al usuario que ingrese los valores
        System.out.println("Ingrese su nombre:");
        nombre = input.nextLine();
        
        System.out.println("Ingrese su edad:");
        edad = input.nextInt();
        
        //Muestro en pantalla lo que ingreso el usuario
        System.out.println(nombre);
        System.out.println(edad);

    }
    
}
