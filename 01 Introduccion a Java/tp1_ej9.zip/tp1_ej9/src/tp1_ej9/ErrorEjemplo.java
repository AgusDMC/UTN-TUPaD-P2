package tp1_ej9;

/**
 *
 * @author Agustin Echeverria Araya
 */

import java.util.Scanner;

public class ErrorEjemplo {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingresa tu nombre: ");
        //String nombre = scanner.nextInt();
        String nombre = scanner.nextLine(); //Error corregido
        System.out.println("Hola, " + nombre);
    }
    
}
