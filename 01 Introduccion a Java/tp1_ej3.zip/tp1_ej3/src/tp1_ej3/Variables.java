package tp1_ej3;

/**
 *
 * @author Agustin Echeverria Araya
 */

public class Variables {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //Declaracion de variables
        String nombre = "Agustin";
        int edad = 27;
        double altura = 1.89;
        boolean estudiante = true;
        
        //Muestro por pantalla los valores de las variables
        System.out.println(nombre);
        System.out.println(edad);
        System.out.println(altura);
        System.out.println(estudiante);
        
    }
    
}
