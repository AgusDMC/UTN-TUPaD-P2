package tp1_ej8;

/**
 *
 * @author Agustin Echeverria Araya
 */

import java.util.Scanner;

public class Tp1_ej8 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        //a
        //Declaro las variables
        //int num1, num2;
        double num1, num2;
        
        //El usuario ingresa los valores
        System.out.println("Ingrese el primer numero");
        //num1 = input.nextInt();
        num1 = input.nextDouble();
        System.out.println("Ingrese el segundo numero");
        //num2 = input.nextInt();
        num2 = input.nextDouble();
        
        //Muestro la division por pantalla
        //System.out.printf("%d / %d = %d\n",num1,num2, num1/num2);
        System.out.printf("%f / %f = %f\n",num1,num2, num1/num2);
        
        
    }
    
}
