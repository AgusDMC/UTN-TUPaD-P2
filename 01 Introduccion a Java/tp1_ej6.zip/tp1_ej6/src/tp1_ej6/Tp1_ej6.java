package tp1_ej6;

/**
 *
 * @author Agustin Echeverria Araya
 */

public class Tp1_ej6 {

    public static void main(String[] args) {
         System.out.println("Nombre: Juan Pérez\nEdad: 30 años\nDirección: \"Calle Falsa 123\"");
    }
    
}
