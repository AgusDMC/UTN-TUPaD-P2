package tp1_ej5;

/**
 *
 * @author Agustin Echeverria Araya
 */

import java.util.Scanner;

public class Tp1_ej5 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        //Decclaro las variables
        int numeroUno, numeroDos, suma, resta, multiplicacion;
        double division = 0;
        
        //Se pide al usuario que ingrese los valores
        System.out.println("Ingrese el primer numero");
        numeroUno = input.nextInt();
        System.out.println("Ingrese el segundo numero");
        numeroDos = input.nextInt();
        
        //Calculo las operaciones
        suma = numeroUno + numeroDos;
        resta = numeroUno - numeroDos;
        multiplicacion = numeroUno * numeroDos;
        if (numeroDos != 0) division = (double) numeroUno / numeroDos;
        
        //Muestro en pantalla los resultados de las operaciones
        System.out.println("Suma: " + suma);
        System.out.println("Resta: " + resta);
        System.out.println("Multiplicacion: " + multiplicacion);
        
        if (numeroDos != 0){
            System.out.println("Division: " + division);
        }
        else {
            System.out.println("No se puede dividir por cero");
        }
    }
    
}
