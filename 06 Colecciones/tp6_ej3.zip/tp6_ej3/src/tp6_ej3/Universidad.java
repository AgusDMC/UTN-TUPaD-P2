package tp6_ej3;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author AgusDMC
 */
public class Universidad {
    private String nombre;
    private List<Curso> cursos;
    private List<Profesor> profesores;

    public Universidad(String nombre) {
        this.nombre = nombre;
        this.cursos = new ArrayList<>();
        this.profesores = new ArrayList<>();
    }

    public void agregarProfesor(Profesor p) {
        if (p != null && !profesores.contains(p)) {
            profesores.add(p);
        }
    }

    public void agregarCurso(Curso c) {
        if (c != null && !cursos.contains(c)) {
            cursos.add(c);
        }
    }

    public Profesor buscarProfesorPorId(String id) {
        if (id == null) return null;
        for (Profesor p : profesores) {
            if (p.getId().equals(id)) return p;
        }
        return null;
    }

    public Curso buscarCursoPorCodigo(String codigo) {
        if (codigo == null) return null;
        for (Curso c : cursos) {
            if (c.getCodigo().equals(codigo)) return c;
        }
        return null;
    }

    public void asignarProfesorACurso(String codigoCurso, String idProfesor) {
        Profesor p = buscarProfesorPorId(idProfesor);
        Curso c = buscarCursoPorCodigo(codigoCurso);
        if (p != null && c != null) {
            c.setProfesor(p); // sincroniza ambos lados
        } else {
            System.out.println("No se pudo asignar: profesor o curso inexistente en " + nombre);
        }
    }

    public void listarProfesores() {
        System.out.println("Profesores de " + nombre + " (total " + profesores.size() + "):");
        for (Profesor p : profesores) p.mostrarInfo();
    }

    public void listarCursos() {
        System.out.println("Cursos de " + nombre + " (total " + cursos.size() + "):");
        for (Curso c : cursos) c.mostrarInfo();
    }

    public void eliminarCurso(String codigo) {
        Curso c = buscarCursoPorCodigo(codigo);
        if (c != null) {
            c.setProfesor(null); // romper relación bidireccional
            cursos.remove(c);
        }
    }

    public void eliminarProfesor(String id) {
        Profesor p = buscarProfesorPorId(id);
        if (p != null) {
            // dejar null en todos los cursos que dictaba
            for (Curso c : new ArrayList<>(p.getCursos())) {
                c.setProfesor(null);
            }
            profesores.remove(p);
        }
    }
}
