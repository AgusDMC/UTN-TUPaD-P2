package tp6_ej3;

/**
 *
 * @author AgusDMC
 */
public class Curso {
    private String codigo;
    private String nombre;
    private Profesor profesor;

    public Curso(String codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
    }

    public String getCodigo() { return codigo; }
    public String getNombre() { return nombre; }
    public Profesor getProfesor() { return profesor; }
    
    public void setCodigo(String codigo) { this.codigo = codigo; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setProfesor(Profesor profesor) {
        // Si es el mismo, no hago nada
        if (profesor == this.profesor) return;

        // Si había profesor previo, me quito de su lista
        if (this.profesor != null) {
            this.profesor.eliminarCurso(this);
        }

        // Asigno el nuevo profesor
        this.profesor = profesor;

        // Si el nuevo profesor no es null y todavía no me tiene, me agrega
        if (profesor != null && !profesor.getCursos().contains(this)) {
            profesor.agregarCurso(this);
        }
    }

    public void mostrarInfo() {
        String nombreProf = (profesor != null ? profesor.getNombre() : "(sin profesor)");
        System.out.println("Curso{codigo='" + codigo + "', nombre='" + nombre + "', profesor=" + nombreProf + "}");
    }
}
