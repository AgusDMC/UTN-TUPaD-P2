package tp6_ej3;

/**
 *
 * @author AgusDMC
 */

public class Tp6_ej3 {
    public static void main(String[] args) {
        
        Profesor p1 = new Profesor("P10", "María González", "Redes");
        Profesor p2 = new Profesor("P20", "Diego Sosa", "Bases de Datos");
        Profesor p3 = new Profesor("P30", "Juliana Pérez", "Matemática");

        Curso c1 = new Curso("C101", "Introducción a Redes");
        Curso c2 = new Curso("C202", "Administración de Servidores");
        Curso c3 = new Curso("C303", "Cálculo I");
        Curso c4 = new Curso("C404", "Diseño de Bases de Datos");
        Curso c5 = new Curso("C505", "Estadística Aplicada");

        Universidad uni = new Universidad("Universidad Nacional de La Pampa");

        // Agregar profesores
        uni.agregarProfesor(p1);
        uni.agregarProfesor(p2);
        uni.agregarProfesor(p3);

        // Agregar cursos
        uni.agregarCurso(c1);
        uni.agregarCurso(c2);
        uni.agregarCurso(c3);
        uni.agregarCurso(c4);
        uni.agregarCurso(c5);

        // Asignación de profesores distinta a la anterior
        uni.asignarProfesorACurso("C101", "P10"); // Redes -> María
        uni.asignarProfesorACurso("C202", "P10"); // Servidores -> María
        uni.asignarProfesorACurso("C303", "P30"); // Cálculo -> Juliana
        uni.asignarProfesorACurso("C404", "P20"); // Bases de Datos -> Diego
        uni.asignarProfesorACurso("C505", "P30"); // Estadística -> Juliana

        System.out.println("\nCursos actuales:");
        uni.listarCursos();

        System.out.println("\nProfesores actuales:");
        uni.listarProfesores();

        // Cambio de profesor como lo pide el enunciado
        System.out.println("\nReasignando profesor del curso C202...");
        uni.asignarProfesorACurso("C202", "P20");
        uni.listarCursos();

        // Eliminación de curso
        System.out.println("\nEliminando curso C303...");
        uni.eliminarCurso("C303");
        uni.listarCursos();
        uni.listarProfesores();

        // Eliminación de profesor
        System.out.println("\nEliminando profesor P10 (María)...");
        uni.eliminarProfesor("P10");
        uni.listarProfesores();
        uni.listarCursos();
    }
    
}
