package tp6_ej2;
import java.util.List;

/**
 *
 * @author AgusDMC
 */

public class Tp6_ej2 {
    public static void main(String[] args) {
        Biblioteca biblio = new Biblioteca("Biblioteca Central");

        // Autores
        Autor a1 = new Autor("A01", "Jorge Luis Borges", "Argentina");
        Autor a2 = new Autor("A02", "Isabel Allende", "Chile");
        Autor a3 = new Autor("A03", "Gabriel García Márquez", "Colombia");

        // Libros
        biblio.agregarLibro("ISBN-001", "Ficciones", 1944, a1);
        biblio.agregarLibro("ISBN-002", "El Aleph", 1949, a1);
        biblio.agregarLibro("ISBN-003", "La casa de los espíritus", 1982, a2);
        biblio.agregarLibro("ISBN-004", "Cuentos de Eva Luna", 1989, a2);
        biblio.agregarLibro("ISBN-005", "Cien años de soledad", 1967, a3);

        System.out.println("\n1) Listar libros:");
        biblio.listarLibros();

        System.out.println("\n2) Buscar por ISBN (ISBN-003):");
        Libro buscado = biblio.buscarLibroPorIsbn("ISBN-003");
        System.out.println(buscado != null ? buscado : "No encontrado");

        System.out.println("\n3) Libros de 1949:");
        List<Libro> de1949 = biblio.filtrarLibrosPorAnio(1949);
        de1949.forEach(System.out::println);

        System.out.println("\n4) Eliminar ISBN-001 y listar:");
        biblio.eliminarLibro("ISBN-001");
        biblio.listarLibros();

        System.out.println("\n5) Cantidad total de libros:");
        System.out.println(biblio.obtenerCantidadLibros());

        System.out.println("\n6) Autores disponibles:");
        biblio.mostrarAutoresDisponibles();
    }
    
}
