package tp6_ej2;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author AgusDMC
 */

public class Biblioteca {
    private String nombre;
    private List<Libro> libros = new ArrayList<>();
    
    public String getNombre() { return nombre; }

    public void setNombre(String nombre) { this.nombre = nombre;}

    public Biblioteca(String nombre) {
        this.nombre = nombre;
    }

    public void agregarLibro(String isbn, String titulo, int anioPublicacion, Autor autor) {
        libros.add(new Libro(isbn, titulo, anioPublicacion, autor));
    }

    public void listarLibros() {
        if (libros.isEmpty()) {
            System.out.println("No hay libros en la biblioteca.");
            return;
        }
        for (Libro l : libros) l.mostrarInfo();
    }

    public Libro buscarLibroPorIsbn(String isbn) {
        for (Libro libro : libros) {
            if (libro.getIsbn().equals(isbn)) {
                return libro;
            }
        }
        return null;
    }

    public void eliminarLibro(String isbn) {
        if (isbn != null) {
            Libro libroEliminar = this.buscarLibroPorIsbn(isbn);
            if (libroEliminar != null) {
                libros.remove(libroEliminar);
            }
        }
    }

    public int obtenerCantidadLibros() {
        return libros.size();
    }

    public List<Libro> filtrarLibrosPorAnio(int anio) {
        ArrayList<Libro> out = new ArrayList<>();
        for (Libro l : libros) if (l.getAnioPublicacion() == anio) out.add(l);
        return out;
    }

    public void mostrarAutoresDisponibles() {
        System.out.println("Autores en la biblioteca:");
        ArrayList<String> vistos = new ArrayList<>();
        for (Libro l : libros) {
            String nombre = l.getAutor().getNombre();
            if (!vistos.contains(nombre)) {
                vistos.add(nombre);
                l.getAutor().mostrarInfo();
            }
        }
    }
}
