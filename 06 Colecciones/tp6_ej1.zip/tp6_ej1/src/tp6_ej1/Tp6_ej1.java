package tp6_ej1;
import java.util.ArrayList;

/**
 *
 * @author AgusDMC
 */

public class Tp6_ej1 {
    public static void main(String[] args) {
        Inventario inv = new Inventario();

        // 1) Crear al menos cinco productos y agregarlos
        inv.agregarProducto(new Producto("P01", "Arroz", 950, 30, CategoriaProducto.ALIMENTOS));
        inv.agregarProducto(new Producto("P02", "Notebook", 6500, 10, CategoriaProducto.ELECTRONICA));
        inv.agregarProducto(new Producto("P03", "Zapatillas", 2700, 15, CategoriaProducto.ROPA));
        inv.agregarProducto(new Producto("P04", "Silla", 1800, 25, CategoriaProducto.HOGAR));
        inv.agregarProducto(new Producto("P05", "Auriculares",1200, 40, CategoriaProducto.ELECTRONICA));

        System.out.println("\n2) Listar todos los productos:");
        inv.listarProductos();

        System.out.println("\n3) Buscar producto por ID (P03):");
        Producto buscado = inv.buscarProductoPorId("P03");
        System.out.println(buscado != null ? buscado : "No encontrado");

        System.out.println("\n4) Filtrar por categoría ELECTRONICA:");
        ArrayList<Producto> electronica = inv.filtrarPorCategoria(CategoriaProducto.ELECTRONICA);
        electronica.forEach(System.out::println);

        System.out.println("\n5) Eliminar producto P01 y listar restantes:");
        System.out.println(inv.eliminarProducto("P01") ? "Eliminado" : "No encontrado");
        inv.listarProductos();

        System.out.println("\n6) Actualizar stock de P02 a 7 unidades:");
        System.out.println(inv.actualizarStock("P02", 7) ? "Stock actualizado" : "No encontrado");
        System.out.println(inv.buscarProductoPorId("P02"));

        System.out.println("\n7) Total de stock disponible:");
        System.out.println(inv.obtenerTotalStock());

        System.out.println("\n8) Producto con mayor stock:");
        System.out.println(inv.obtenerProductoConMayorStock());

        System.out.println("\n9) Filtrar productos con precio entre $1000 y $3000:");
        inv.filtrarProductosPorPrecio(1000, 3000).forEach(System.out::println);

        System.out.println("\n10) Categorías disponibles:");
        inv.mostrarCategoriasDisponibles();
    }
    
}
