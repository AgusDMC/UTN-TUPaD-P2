package tp8_ej1;

public interface PagoConDescuento {
    double aplicarDescuento(double monto);
}
