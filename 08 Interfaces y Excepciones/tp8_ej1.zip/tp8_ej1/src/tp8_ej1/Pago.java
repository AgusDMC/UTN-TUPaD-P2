package tp8_ej1;

public interface Pago {
    void procesarPago(double monto);
}
