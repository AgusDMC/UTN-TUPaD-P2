package tp8_ej1;

public class Tp8_ej1 {
    public static void main(String[] args) {
        Cliente cliente = new Cliente("Agustín");

        Pedido pedido = new Pedido(cliente);

        Producto p1 = new Producto("Mouse Gamer", 15000);
        Producto p2 = new Producto("Teclado Mecánico", 32000);

        pedido.agregarProducto(p1);
        pedido.agregarProducto(p2);

        System.out.println("Total del pedido: $" + pedido.calcularTotal());

        pedido.cambiarEstado("Pagado");

        // Pago con tarjeta (con descuento)
        TarjetaCredito tc = new TarjetaCredito("4321-1111-2222-9876");

        double totalConDescuento = tc.aplicarDescuento(pedido.calcularTotal());
        tc.procesarPago(totalConDescuento);

        pedido.cambiarEstado("Enviado");
    }    
}
