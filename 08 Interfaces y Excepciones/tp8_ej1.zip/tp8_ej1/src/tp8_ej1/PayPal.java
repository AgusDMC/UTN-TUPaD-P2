package tp8_ej1;

public class PayPal implements Pago {

    private String email;

    public PayPal(String email) {
        this.email = email;
    }

    @Override
    public void procesarPago(double monto) {
        System.out.println("Pago realizado vía PayPal de $" + monto + " desde " + email);
    }
}
