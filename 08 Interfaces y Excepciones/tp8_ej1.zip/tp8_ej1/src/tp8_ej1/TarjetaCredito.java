package tp8_ej1;

public class TarjetaCredito implements Pago, PagoConDescuento {

    private String numero;

    public TarjetaCredito(String numero) {
        this.numero = numero;
    }

    @Override
    public double aplicarDescuento(double monto) {
        return monto * 0.90; // 10% OFF
    }

    @Override
    public void procesarPago(double monto) {
        System.out.println("Pagando $" + monto + " con tarjeta " + numero);
    }
}
