package tp8_ej1;

public interface Notificable {
    void notificar(String mensaje);
}
