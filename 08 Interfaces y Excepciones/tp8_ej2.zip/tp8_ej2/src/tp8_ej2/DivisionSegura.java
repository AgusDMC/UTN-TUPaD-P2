package tp8_ej2;

import java.util.Scanner;

public class DivisionSegura {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Ingrese el numerador: ");
            int numerador = Integer.parseInt(scanner.nextLine());

            System.out.print("Ingrese el denominador: ");
            int denominador = Integer.parseInt(scanner.nextLine());

            int resultado = numerador / denominador; // puede lanzar ArithmeticException
            System.out.println("Resultado: " + resultado);

        } catch (ArithmeticException e) {
            System.out.println("Error: no se puede dividir por cero.");
        } catch (NumberFormatException e) {
            System.out.println("Error: debe ingresar solo números enteros.");
        } finally {
            System.out.println("Fin de la operación de división.");
            scanner.close();
        }
    }
}
