package tp8_ej2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class LecturaArchivoTryWithResources {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el nombre del archivo a leer (try-with-resources): ");
        String nombreArchivo = scanner.nextLine();

        // try-with-resources: cierra el BufferedReader automáticamente
        try (BufferedReader reader = new BufferedReader(new FileReader(nombreArchivo))) {

            String linea;
            System.out.println("\nContenido del archivo:");
            while ((linea = reader.readLine()) != null) {
                System.out.println(linea);
            }

        } catch (IOException e) {
            System.out.println("Error de E/S al trabajar con el archivo: " + e.getMessage());
        } finally {
            System.out.println("Fin de la lectura con try-with-resources.");
            scanner.close();
        }
    }
}
