package tp8_ej2;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class LecturaArchivo {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el nombre del archivo a leer: ");
        String nombreArchivo = scanner.nextLine();

        BufferedReader reader = null;

        try {
            reader = new BufferedReader(new FileReader(nombreArchivo)); // puede lanzar FileNotFoundException
            String linea;
            System.out.println("\nContenido del archivo:");
            while ((linea = reader.readLine()) != null) {
                System.out.println(linea);
            }

        } catch (FileNotFoundException e) {
            System.out.println("Error: el archivo \"" + nombreArchivo + "\" no existe o no se puede abrir.");
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        } finally {
            System.out.println("\nCerrando recursos...");
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException e) {
                System.out.println("No se pudo cerrar el archivo correctamente.");
            }
            scanner.close();
        }
    }
}

