package tp8_ej2;

import java.util.Scanner;

public class ValidadorEdad {

    public static void validarEdad(int edad) throws EdadInvalidaException {
        if (edad < 0 || edad > 120) {
            throw new EdadInvalidaException("Edad inválida: " + edad + ". Debe estar entre 0 y 120.");
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese su edad: ");
        String texto = scanner.nextLine();

        try {
            int edad = Integer.parseInt(texto);
            validarEdad(edad);
            System.out.println("Edad válida: " + edad);
        } catch (NumberFormatException e) {
            System.out.println("Error: debe ingresar un número entero para la edad.");
        } catch (EdadInvalidaException e) {
            System.out.println("Se produjo una EdadInvalidaException: " + e.getMessage());
        } finally {
            System.out.println("Fin de la validación de edad.");
            scanner.close();
        }
    }
}
