package tp8_ej2;

import java.util.Scanner;

public class ConversionCadenaNumero {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese un número entero en texto: ");
        String texto = scanner.nextLine();

        try {
            int valor = Integer.parseInt(texto); // puede lanzar NumberFormatException
            System.out.println("Conversión exitosa. El número es: " + valor);
        } catch (NumberFormatException e) {
            System.out.println("Error: \"" + texto + "\" no es un número entero válido.");
        } finally {
            System.out.println("Fin de la conversión.");
            scanner.close();
        }
    }
}
