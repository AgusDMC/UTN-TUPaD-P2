package tp8_ej2;

public class Tp8_ej2 {
    public static void main(String[] args) {
        
    }  
}
