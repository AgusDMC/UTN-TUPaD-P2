package tp4;

/**
 *
 * @author Agustin Echeverria Araya
 */

public class Tp4 {
    public static void main(String[] args) {
        // Instanciar usando constructor completo
        Empleado emp1 = new Empleado(1, "Juan Pérez", "Desarrollador", 5000.0);
        Empleado emp2 = new Empleado(2, "María López", "Gerente", 8000.0);

        // Instanciar usando constructor con nombre y puesto (id auto, salario default)
        Empleado emp3 = new Empleado("Carlos Gómez", "Analista");
        Empleado emp4 = new Empleado("Ana Martínez", "Diseñadora");

        // Aplicar métodos sobrecargados de actualizarSalario
        emp1.actualizarSalario(10.0); // Aumento por porcentaje (10%)
        emp2.actualizarSalario(500.0, true); // Aumento por cantidad fija (500)
        emp3.actualizarSalario(15.0); // Aumento por porcentaje (15%)
        emp4.actualizarSalario(300.0, true); // Aumento por cantidad fija (300)

        // Imprimir información con toString
        System.out.println(emp1);
        System.out.println(emp2);
        System.out.println(emp3);
        System.out.println(emp4);

        // Mostrar total de empleados
        System.out.println("Total de empleados creados: " + Empleado.mostrarTotalEmpleados());
    }
}
