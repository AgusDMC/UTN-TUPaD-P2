package tp7_ej1;

public class Tp7_ej1 {
    public static void main(String[] args) {
        Auto autoCiudad = new Auto("Peugeot", "208", 5);
        Auto autoDeportito = new Auto("Ford", "Mustang", 3);

        System.out.println("=== Datos de los autos cargados ===");
        autoCiudad.mostrarInfo();
        System.out.println("--------------------------");
        autoDeportito.mostrarInfo();
    }
}
