package tp7_ej4;

public class Perro extends Animal {

    public Perro(String nombre) {
        super(nombre);
    }

    @Override
    public void hacerSonido() {
        System.out.println("Guau guau");
    }

    @Override
    public void describirAnimal() {
        System.out.println("Soy un perro llamado " + getNombre() + ".");
    }
}
