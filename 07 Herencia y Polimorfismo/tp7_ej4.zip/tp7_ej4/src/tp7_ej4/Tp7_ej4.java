package tp7_ej4;

import java.util.ArrayList;

public class Tp7_ej4 {
    public static void main(String[] args) {
        ArrayList<Animal> animales = new ArrayList<>();
        animales.add(new Perro("Firulais"));
        animales.add(new Gato("Michi"));
        animales.add(new Vaca("Lola"));
        animales.add(new Perro("Sultan"));

        System.out.println("=== Sonidos de animales (polimorfismo) ===");
        for (Animal animal : animales) {
            animal.describirAnimal();  // llamada polimorfica
            animal.hacerSonido();      // llamada polimorfica
            System.out.println("------------------------------");
        }
    }   
}
