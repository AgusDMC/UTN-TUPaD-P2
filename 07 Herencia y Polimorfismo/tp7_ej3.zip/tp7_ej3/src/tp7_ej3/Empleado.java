package tp7_ej3;

public abstract class Empleado {
    private String nombre;

    public Empleado(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() { return nombre; }

    // cada tipo de empleado define como calcula su sueldo
    public abstract double calcularSueldo();
}
