package tp7_ej3;

import java.util.ArrayList;

public class Tp7_ej3 {
    public static void main(String[] args) {
        ArrayList<Empleado> empleados = new ArrayList<>();

        empleados.add(new EmpleadoPlanta("Ana", 220000, 4, 9000));
        empleados.add(new EmpleadoTemporal("Lucas", 120, 1800));
        empleados.add(new EmpleadoPlanta("María", 250000, 1, 10000));
        empleados.add(new EmpleadoTemporal("Sofía", 80, 1600));

        int cantidadPlanta = 0;
        int cantidadTemporales = 0;

        System.out.println("=== Nomina de empleados ===");
        for (Empleado e : empleados) {
            double sueldo = e.calcularSueldo();   // llamada polimórfica
            System.out.println(e.getNombre() + " cobra: $" + sueldo);

            if (e instanceof EmpleadoPlanta) {
                cantidadPlanta++;
            } else if (e instanceof EmpleadoTemporal) {
                cantidadTemporales++;
            }
        }

        System.out.println("-----------------------------");
        System.out.println("Empleados de planta: " + cantidadPlanta);
        System.out.println("Empleados temporales: " + cantidadTemporales);
    } 
}
