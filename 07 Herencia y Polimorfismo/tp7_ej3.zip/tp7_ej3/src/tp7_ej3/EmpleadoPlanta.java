package tp7_ej3;

public class EmpleadoPlanta extends Empleado {

    private double sueldoBasico;
    private int aniosAntiguedad;
    private double extraPorAnio;   // monto fijo por año

    public EmpleadoPlanta(String nombre, double sueldoBasico, int aniosAntiguedad, double extraPorAnio) {
        super(nombre);
        this.sueldoBasico = sueldoBasico;
        this.aniosAntiguedad = aniosAntiguedad;
        this.extraPorAnio = extraPorAnio;
    }

    @Override
    public double calcularSueldo() {
        // sueldo básico + un adicional fijo por año de antigüedad
        return sueldoBasico + aniosAntiguedad * extraPorAnio;
    }
}
