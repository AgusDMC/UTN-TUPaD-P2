package tp7_ej2;

public abstract class Figura {
    private String nombre;

    public Figura(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() { return nombre; }

    // método abstracto: cada subclase define cómo calcula el área
    public abstract double calcularArea();

    // método concreto común a todas las figuras
    public void mostrarArea() {
        System.out.println("Área de " + nombre + ": " + calcularArea());
    }
}
