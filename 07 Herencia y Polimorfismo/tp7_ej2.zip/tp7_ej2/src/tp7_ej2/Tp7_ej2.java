package tp7_ej2;

public class Tp7_ej2 {
    public static void main(String[] args) {
        Figura[] figuras = new Figura[4];

        figuras[0] = new Circulo(2.0);
        figuras[1] = new Rectangulo(3.0, 4.0);
        figuras[2] = new Circulo(1.5);
        figuras[3] = new Rectangulo(5.0, 2.0);

        double areaTotal = 0;

        System.out.println("=== Cálculo de áreas con polimorfismo ===");
        for (Figura f : figuras) {
            f.mostrarArea();                 // llamada polimorfica
            areaTotal += f.calcularArea();   // tambien polimorfica
            System.out.println("---------------------------");
        }

        System.out.println("Area total de todas las figuras: " + areaTotal);
    } 
}
